//
//  TestColorApp.swift
//  TestColor
//
//  Created by user189629 on 3/19/21.
//

import SwiftUI

@main
struct TestColorApp: App {
    var body: some Scene {
        WindowGroup {
            InicioView()
        }
    }
}
