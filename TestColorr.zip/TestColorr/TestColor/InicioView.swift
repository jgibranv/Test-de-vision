//
//  ContentView.swift
//  TestColor
//
//  Created by user189629 on 3/19/21.
//

import SwiftUI

struct InicioView: View {
    
    var arrOpciones = ["Realizar Examen"]
    
    var body: some View {
    
        ZStack {
            VStack(spacing:0){
                VStack{
                    ZStack{
                        Color("ELECTROMAGNETIC")
                            .edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
                        VStack{
                            Text("Prueba de Daltonismo")
                                .font(.custom("Lemonada-Regular",size:30))
                                .foregroundColor(Color("SwanWhite"))
                            
                        }
                    }
                }
                NavigationView{
                    VStack {
                        List(0..<arrOpciones.count) { item in
                            HStack {
                                //Text("\(item)")
                                Image(systemName:"eye")
                                Text(arrOpciones[item])
                                    //.padding()
                            }
                        }
                                
                        .listStyle(GroupedListStyle())
                       // .navigationBarTitle(Text("Lista de Colores"), displayMode: .inline)
                    }
                }
                .accentColor(Color("DarkText"))
                            
                    }
            HStack{
                Image("ish1")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .clipShape(Circle())
                    .frame(width: 99, height: 99, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                Image("ish2")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .clipShape(Circle())
                    .frame(width: 99, height: 99, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                Image("ish3")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .clipShape(Circle())
                    .frame(width: 99, height: 99, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                Image("ish4")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .clipShape(Circle())
                    .frame(width: 99, height: 99, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                
            }
                }
            }
        }


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        InicioView()
    }
}
