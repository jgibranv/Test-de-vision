//
//  IchiharaView.swift
//  TestColor
//
//  Created by user189629 on 3/19/21.
//

import SwiftUI

struct IchiharaView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct IchiharaView_Previews: PreviewProvider {
    static var previews: some View {
        IchiharaView()
    }
}
