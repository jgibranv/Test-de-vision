//
//  Media.swift
//  TestColor
//
//  Created by Karla Gonzalez on 22/03/21.
//

import SwiftUI

struct Media: Identifiable{

    var id = UUID()
    var sNameFoto: String
    var iNumber: Int


}
