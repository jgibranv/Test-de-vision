//
//  ContentView.swift
//  TestColor
//
//  Created by user189629 on 3/19/21.
//

import SwiftUI

struct ContentView: View {
    
    @StateObject var media = MediaModel()
    
    var body: some View {
 
                
                IshiharaView(media : media)
                    .tabItem {
                        Label("Movies", systemImage: "film.fill")
                    }

  
        .accentColor(Color("MidnightBlue"))
        .onAppear{
            UITabBar.appearance().barTintColor = UIColor(Color("CityLights"))
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
