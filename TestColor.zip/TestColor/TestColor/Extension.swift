//
//  Extension.swift
//  TestColor
//
//  Created by Karla Gonzalez on 22/03/21.
//

import SwiftUI

extension Media{
    public static var defaultMedia = Media(sNameFoto: "2", iNumber: 2)
}
